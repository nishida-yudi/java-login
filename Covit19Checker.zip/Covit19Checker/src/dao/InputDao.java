package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import dto.CreateTargetDto;
import dto.ManagerDailyReportDto;
import dto.RegistDto;
import entity.InputEntity;

public class InputDao {



	//日付照会・入力データ取得処理
	public List<InputEntity> findInputDay(ManagerDailyReportDto condition) {

		List<InputEntity> list = new ArrayList<InputEntity>();

		try {
			Context initContext = new InitialContext();
			Context envContext = (Context)initContext.lookup("java:/comp/env");
			DataSource dataSource = (DataSource)envContext.lookup("jdbc/covit19_checker");
			Connection connection = dataSource.getConnection();

			String sql = " select "
					+ "  id, "
					+ "	 users_id, "
					+ "	 input_day, "
					+ "	 temperature, "
					+ "	 corona_check1  , "
					+ "	 corona_check2  , "
					+ "	 corona_check3  , "
					+ "	 corona_check4  , "
					+ "	 corona_check5  , "
					+ "	 corona_check6  "
					+ " from  "
					+ "	 input "
					+ " where "
					+ "	 input_day = ? ;";

			PreparedStatement preparedStatement = connection.prepareStatement(sql);

			//SQLのDate型に変換   java.sql.Date
			Date sqlDate = Date.valueOf(condition.getInputDay());
			preparedStatement.setDate(1, sqlDate);
			ResultSet resultSet = preparedStatement.executeQuery();

			//List<InputEntity> list = new ArrayList<InputEntity>();
			while(resultSet.next()) {

				InputEntity inputEntity = new InputEntity();
				inputEntity.setId(resultSet.getInt("id"));
				if(resultSet.wasNull()) {
					inputEntity.setId(null);
				}

				inputEntity.setUsersId(resultSet.getInt("users_id"));
				inputEntity.setInputDay(resultSet.getString("input_day"));
				inputEntity.setTemperature(resultSet.getString("temperature"));
				inputEntity.setCoronaCheck1(resultSet.getString("corona_check1"));
				inputEntity.setCoronaCheck2(resultSet.getString("corona_check2"));
				inputEntity.setCoronaCheck3(resultSet.getString("corona_check3"));
				inputEntity.setCoronaCheck4(resultSet.getString("corona_check4"));
				inputEntity.setCoronaCheck5(resultSet.getString("corona_check5"));
				inputEntity.setCoronaCheck6(resultSet.getString("corona_check6"));
				list.add(inputEntity);

			}

			connection.close(); //Contextに戻すイメージ

			return list;
			//検索結果＝０件　→　要素数０のlist を返す方が後の処理が書きやすい

		} catch (Exception e) {
			e.printStackTrace();
		}
		//return null;
		return list;
	}

	public void regist(RegistDto registDto) {
		// TODO 自動生成されたメソッド・スタブ
		try {
			Context initContext = new InitialContext();
			Context envContext = (Context)initContext.lookup("java:/comp/env");
			DataSource dataSource = (DataSource)envContext.lookup("jdbc/covit19_checker");
			Connection connection = dataSource.getConnection();

			String sql = " select "
					+ "  id, "
					+ "	 users_id, "
					+ "	 input_day, "
					+ "	 temperature, "
					+ "	 corona_check1  , "
					+ "	 corona_check2  , "
					+ "	 corona_check3  , "
					+ "	 corona_check4  , "
					+ "	 corona_check5  , "
					+ "	 corona_check6  "
					+ " from  "
					+ "	 input "
					+ " where "
					+ "	 users_id = ? "
					+ "	 and "
					+ "	 input_day = ? ;";
			PreparedStatement preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setInt(1, registDto.getUsersId());
			//registDtoのString型inputDayを、SQLのDate型に変換   java.sql.Date
			Date sqlDate = Date.valueOf(registDto.getInputDay());
			preparedStatement.setDate(2, sqlDate);
			ResultSet resultSet = preparedStatement.executeQuery();

			List<InputEntity> list = new ArrayList<InputEntity>();
			while(resultSet.next()) {
				InputEntity inputEntity = new InputEntity();
				inputEntity.setUsersId(resultSet.getInt("id"));

				//同一日・同一ユーザーのデータが存在する場合、一旦登録されている
				//データを削除する（削除後、上書きする為）。
				if(!(resultSet.wasNull())) {
					String sql1 = " delete "
							+ " from input "
							+ " where "
							+ " users_id = ? "
							+ " and "
							+ "input_day = ? ; ";

					PreparedStatement ps = connection.prepareStatement(sql1);
					ps.setInt(1, registDto.getUsersId());
					ps.setDate(2, sqlDate);
					//削除した行数は返さない。
					 ps.executeUpdate();

				}

				//ERROR: 列"users_id"は存在しません
				 //ヒント: テーブル"input"には"users_id"という名前の列がありますが、問い合わせのこの部分からは参照できません。


			}
			//入力値をデータベースに登録する。
			String sql2 = " insert into input( "
				    + " users_id, "
					+ " input_day, "
				    + " temperature, "
					+ " corona_check1, "
				    + " corona_check2, "
					+ " corona_check3, "
				    + " corona_check4, "
					+ " corona_check5, "
				    + " corona_check6 "
				    + " ) values ( "
				    + " ?, "
				    + " ?, "
				    + " ?, "
				    + " ?, "
				    + "  ?, "
				    + " ?, "
				    + " ?, "
				    + " ?, "
				    + " ?); ";
			PreparedStatement ps = connection.prepareStatement(sql2);
			ps.setInt(1, registDto.getUsersId());
			ps.setDate(2, sqlDate);
			ps.setString(3, registDto.getTemperature());
			ps.setString(4, registDto.getCorona_check1());
			ps.setString(5, registDto.getCorona_check2());
			ps.setString(6, registDto.getCorona_check3());
			ps.setString(7, registDto.getCorona_check4());
			ps.setString(8, registDto.getCorona_check5());
			ps.setString(9, registDto.getCorona_check6());

			ps.executeUpdate();
			connection.close();

		} catch (Exception e) {
			e.printStackTrace();
		}


	}

	public List<InputEntity> findRegistData(CreateTargetDto condition) {

		List<InputEntity> inputList = new ArrayList<InputEntity>();

		try {
			Context initContext = new InitialContext();
			Context envContext = (Context)initContext.lookup("java:/comp/env");
			DataSource dataSource = (DataSource)envContext.lookup("jdbc/covit19_checker");
			Connection connection = dataSource.getConnection();

			String sql = " select "
					+ "  id, "
					+ "	 users_id, "
					+ "	 input_day, "
					+ "	 temperature, "
					+ "	 corona_check1  , "
					+ "	 corona_check2  , "
					+ "	 corona_check3  , "
					+ "	 corona_check4  , "
					+ "	 corona_check5  , "
					+ "	 corona_check6  "
					+ " from  "
					+ "	 input "
					+ " where "
					+ " users_id = ? "
					+ " and "
					+ "	 input_day <= ? "
					+ " order by "
					+ "  input_day desc "
					+ " limit 14 ; " ;

			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, condition.getUsersId());

			//preparedStatement.setString(2, condition.getTargetYMD());

			//SQLのDate型に変換   java.sql.Date
			Date sqlDate = Date.valueOf(condition.getTargetYMD());
			preparedStatement.setDate(2, sqlDate);

			ResultSet resultSet = preparedStatement.executeQuery();

			//List<InputEntity> inputList = new ArrayList<InputEntity>();
			while(resultSet.next()) {

				InputEntity inputEntity = new InputEntity();
				inputEntity.setId(resultSet.getInt("id"));
				if(resultSet.wasNull()) {
					inputEntity.setId(null);
				}

				inputEntity.setUsersId(resultSet.getInt("users_id"));
				inputEntity.setInputDay(resultSet.getString("input_day"));
				inputEntity.setTemperature(resultSet.getString("temperature"));
				inputEntity.setCoronaCheck1(resultSet.getString("corona_check1"));
				inputEntity.setCoronaCheck2(resultSet.getString("corona_check2"));
				inputEntity.setCoronaCheck3(resultSet.getString("corona_check3"));
				inputEntity.setCoronaCheck4(resultSet.getString("corona_check4"));
				inputEntity.setCoronaCheck5(resultSet.getString("corona_check5"));
				inputEntity.setCoronaCheck6(resultSet.getString("corona_check6"));
				inputList.add(inputEntity);

			}

			connection.close(); //Contextに戻すイメージ

			return inputList;
			//検索結果＝０件　→　要素数０のlist を返す方が後の処理が書きやすい

		} catch (Exception e) {
			e.printStackTrace();
		}
		//return null;
		return inputList;
	}

}
