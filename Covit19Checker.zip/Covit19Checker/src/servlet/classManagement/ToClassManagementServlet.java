package servlet.classManagement;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.UsersDao;
import entity.UserEntity;

/**
 * クラス管理遷移サーブレット
 */
@WebServlet("/manager/ToClassManagementServlet")
public class ToClassManagementServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//リクエストパラメータ取得
		String className =  request.getParameter("className");

		//リクエストパラメータ入力チェック
		if(className == "" || className == null) {

			//リクエストスコープにエラーメッセージをセット
			request.setAttribute("errorMessage2", "クラス名が未入力です");

			//管理者メニューへ遷移
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("/WEB-INF/managerMenu.jsp");
			requestDispatcher.forward(request, response);
			return;
		}

		//【確認用】
		System.out.println("[ToClassManagementServlet]getParameter => " + className);

		//クラス内のユーザのデータを取得
		UsersDao usersDao = new UsersDao();
		List<UserEntity> usersList  = usersDao.findClassUsers(className);

		//要素がない場合にTRUEを返す
		if( usersList.isEmpty() ) {

			//リクエストスコープにエラーメッセージをセット
			request.setAttribute("errorMessage2", "ユーザーテーブルからデータを取得できませんでした。");
			//管理者メニューへ遷移
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("/WEB-INF/managerMenu.jsp");
			requestDispatcher.forward(request, response);
			return;

		} else {
			//結果をセッションスコープに保存
			HttpSession session = request.getSession();
			session.setAttribute("userList", usersList);

			//クラス管理画面へ遷移
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("/WEB-INF/classManagement.jsp");
			requestDispatcher.forward(request, response);
			return;

		}

	}

}
