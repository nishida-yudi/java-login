package servlet.classManagement;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * 管理者メニュー初期化サーブレッド
 */
@WebServlet("/manager/ManagerMenuInitServlet")
public class ManagerMenuInitServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//セッションスコープ
		HttpSession session = request.getSession();

		//セッションスコープから削除
		session.removeAttribute("UserList");

		//【確認用】
		//System.out.println("[ManagerMenuInitServlet]管理者メニュー画面へ遷移する");

		//管理者メニュー画面へ遷移する
		response.sendRedirect(request.getContextPath() + "/manager/ManagerMenuServlet");
		//RequestDispatcher requestDispatcher = request.getRequestDispatcher("/manager/ManagerMenuServlet");
		//requestDispatcher.forward(request, response);




	}


}
