package servlet.classManagement;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.UsersDao;
import entity.UserEntity;

/**
 * クラス管理確認サーブレッド
 */
@WebServlet("/manager/ClassManagementConfirmServlet")
public class ClassManagementConfirmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {


		//リクエストパラメータ取得
		String action =  request.getParameter("action");

		if(action.equals("back")) {
			//「戻る」ボタン押下
			//クラス管理画面へ遷移
			RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/classManagement.jsp");
			dispatcher.forward(request, response);
			return;
		}

		if(action.equals("send")) {
			//「確認画面へ」ボタン押下

			List<UserEntity> sessionUsersList = new ArrayList<UserEntity>();
			UsersDao usersDao = new UsersDao();

			//■セッションスコープからユーザリストを取り出す。
			HttpSession session = request.getSession();
			List<UserEntity> usersList = (List<UserEntity> )session.getAttribute("userList");

			for (UserEntity userEntity : usersList) {
				sessionUsersList.add(userEntity);
			}

			if(sessionUsersList.size() != 0) {
				if( usersDao.overWriteUser(sessionUsersList) ) {
					//クラス管理完了画面へ遷移
					//【確認用】
					System.out.println("[ClassManagementConfirmServlet]クラス管理完了画面へ遷移");

					RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/classManagementComplete.jsp");
					dispatcher.forward(request, response);
					//response.sendRedirect(request.getContextPath()+"/WEB-INF/classManagementComplete.jsp");
					//response.sendRedirect("Covit19Checker/WEB-INF/classManagementComplete.jsp");
					///Covit19Checker/WebContent/WEB-INF/classManagementComplete.jsp
					return;

				} else {
					System.out.println("[ClassManagementConfirmServletusers]テーブルの更新に失敗！！");
					//TODO 遷移先はどこ？ エラーメッセージはどうする？
					RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/classManagementConfirm.jsp");
					dispatcher.forward(request, response);
					return;
				}
			}

		}

	}
}


