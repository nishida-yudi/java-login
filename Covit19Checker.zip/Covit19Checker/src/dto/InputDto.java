package dto;

import java.io.Serializable;

public class InputDto implements Serializable {

	private String inputMember;		//入力メンバー名
	private String temperature;		//体温
	private String coronaRisk;		//コロナ危険度


	public String getInputMember() {
		return inputMember;
	}
	public void setInputMember(String inputMember) {
		this.inputMember = inputMember;
	}
	public String getTemperature() {
		return temperature;
	}
	public void setTemperature(String temperature) {
		this.temperature = temperature;
	}
	public String getCoronaRisk() {
		return coronaRisk;
	}
	public void setCoronaRisk(String coronaRisk) {
		this.coronaRisk = coronaRisk;
	}




}
