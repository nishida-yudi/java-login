package constant;

public class Constant {
	public static final String SESSION_KEY_LOGIN_INFO = "SESSION_KEY_LOGIN_INFO";
	public static final String PUBLIC_URL_PREFIX_PUBLIC = "/public/";
	public static final String PUBLIC_URL_PREFIX_STATIC = "/static/";
}
