package service;

import java.util.List;

import dao.ManagerDao;
import entity.ManagerEntity;
import util.Util;

/**
 * ユーザサービス
 */
public class ManagerService {


	public List<ManagerEntity> searchManager(ManagerEntity condition) {
		ManagerDao managerDao = new ManagerDao();
		ManagerEntity managerEntity = new ManagerEntity();
		managerEntity.setLoginId(condition.getLoginId());
		String passwordMd5 = Util.digest(condition.getLoginPassword());
		managerEntity.setLoginPassword(passwordMd5);
		return managerDao.findManager(managerEntity);
	}
}


