
	package dao;

	import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import entity.ManagerEntity;

	/**
	 * ユーザDaos
	 */
	public class ManagerDao {

		public List<ManagerEntity> findManager(ManagerEntity condition){

			List<ManagerEntity> list = new ArrayList<ManagerEntity>();
			try {
				Context initContext = new InitialContext();
				Context envContext = (Context)initContext.lookup("java:/comp/env");
				DataSource dataSource = (DataSource)envContext.lookup("jdbc/covit19_checker");
				Connection connection = dataSource.getConnection();

				String sql =
						  " select "
						+ "   id, "
						+ "   login_id, "
						+ "   login_password "
						+ " from "
						+ "   manager "
						+ " where "
						+ "   login_id = ? "
						+ " and "
						+ "   login_password = ? "
						+ " ;";

				PreparedStatement preparedStatement = connection.prepareStatement(sql);
				preparedStatement.setString(1, condition.getLoginId());
				preparedStatement.setString(2, condition.getLoginPassword());
				ResultSet resultSet = preparedStatement.executeQuery();

				while(resultSet.next()) {
					ManagerEntity managerEntity = new ManagerEntity();
					if(resultSet.wasNull()) {
						managerEntity.setId(null);
					}
					managerEntity.setLoginId(resultSet.getString("login_id"));
					managerEntity.setLoginPassword(resultSet.getString("login_password"));


					list.add(managerEntity);
				}
				connection.close();
				return list;
			} catch (Exception e) {
				e.printStackTrace();
			}

			return list;
		}
	}


