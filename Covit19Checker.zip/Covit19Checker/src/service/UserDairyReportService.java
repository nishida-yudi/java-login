package service;

import java.util.ArrayList;
import java.util.List;

import dao.InputDao;
import dao.UsersDao;
import dto.CreateTargetDto;
import dto.UserDairyReportDataDto;
import entity.InputEntity;
import entity.UserEntity;

public class UserDairyReportService {

	public List<UserDairyReportDataDto> createDairyReportData(CreateTargetDto createTargetDto) {

		InputDao inputDao = new InputDao();
		UsersDao usersDao = new UsersDao();

		//ArryaListを使用し、日別状況レポートリストを生成する。
		List<UserDairyReportDataDto> list = new ArrayList<UserDairyReportDataDto>();

		//ユーザDAOのユーザー検索を呼び出す。
		List<UserEntity> userList = usersDao.findUsers(createTargetDto);

		//戻り値．ユーザーリストが１件の場合、作成対象dtoにユーザーリストのユーザーIDを代入する。
		if(userList.size() == 1) {
			for (UserEntity userEntity : userList) {
				createTargetDto.setUsersId(userEntity.getId());
			}
		}

		//【確認用】
		//System.out.println("[UserDairyReportService]userList.size() => " + userList.size());

		//登録データリスト（１件目）．入力データエンティティ．日付と作成対象dto．基準日を比較する
		List<InputEntity> inputList = inputDao.findRegistData(createTargetDto);

		if(inputList.isEmpty()) {
			return list;
		}

		InputEntity inputEntity = inputList.get(0);

		if (!(inputEntity.getInputDay().equals(createTargetDto.getTargetYMD()))) {
			return list;
		}

		UserEntity userEntity = userList.get(0);

		//取得したデータから最大１４件の日別状況レポートリストを作成する。
		for (InputEntity inputEntity1 : inputList) {
			UserDairyReportDataDto userDairyReportDataDto = new UserDairyReportDataDto();
			userDairyReportDataDto.setLoginId(userEntity.getLoginId());
			userDairyReportDataDto.setUsersName(userEntity.getUsersName());
			userDairyReportDataDto.setNormalTemperature(userEntity.getNormalTemperature());
			userDairyReportDataDto.setTargetYMD(createTargetDto.getTargetYMD());
			userDairyReportDataDto.setInputDay(inputEntity1.getInputDay());
			userDairyReportDataDto.setTemperature(inputEntity1.getTemperature());
			userDairyReportDataDto.setCoronaCheck1(Integer.parseInt(inputEntity1.getCoronaCheck1()));
			userDairyReportDataDto.setCoronaCheck2(Integer.parseInt(inputEntity1.getCoronaCheck2()));
			userDairyReportDataDto.setCoronaCheck3(Integer.parseInt(inputEntity1.getCoronaCheck3()));
			userDairyReportDataDto.setCoronaCheck4(Integer.parseInt(inputEntity1.getCoronaCheck4()));
			userDairyReportDataDto.setCoronaCheck5(Integer.parseInt(inputEntity1.getCoronaCheck5()));
			userDairyReportDataDto.setCoronaCheck6(Integer.parseInt(inputEntity1.getCoronaCheck6()));

			if( userDairyReportDataDto.getCoronaCheck1() >= 2) {
				userDairyReportDataDto.setComment1("対策OKです。引き続き手洗いの徹底・マスクの着用しよう！");
			}  else {
				userDairyReportDataDto.setComment1("対策が不十分です。手洗いの徹底・マスクの着用しよう！");
			}

			if( userDairyReportDataDto.getCoronaCheck2() >= 2) {
				userDairyReportDataDto.setComment2("対策OKです。引き続きソーシャルディスタンスを意識しよう！");
			}  else {
				userDairyReportDataDto.setComment2("対策が不十分です。ソーシャルディスタンスを意識しよう！");
			}

			if( userDairyReportDataDto.getCoronaCheck3() >= 2) {
				userDairyReportDataDto.setComment3("対策OKです。引き続き３密を避けよう！");
			}  else {
				userDairyReportDataDto.setComment3("対策が不十分です。３密を避けよう！");
			}

			if( userDairyReportDataDto.getCoronaCheck4() >= 2) {
				userDairyReportDataDto.setComment4("対策OKです。引き続き体調管理を徹底しよう！");
			}  else {
				userDairyReportDataDto.setComment4("対策が不十分です。体調管理を徹底しよう！");
			}

			if( userDairyReportDataDto.getCoronaCheck5() >= 2) {
				userDairyReportDataDto.setComment5("対策OKです。引き続き不要不急の外出を控えよう！");
			}  else {
				userDairyReportDataDto.setComment5("対策が不十分です。不要不急の外出を控えよう！");
			}

			if( userDairyReportDataDto.getCoronaCheck6() >= 2) {
				userDairyReportDataDto.setComment6("対策OKです。引き続き他人との接触を控えよう！");
			}  else {
				userDairyReportDataDto.setComment6("対策が不十分です。他人との接触を控えよう！");
			}

			userDairyReportDataDto.setTotaleValuationPoint(
												Integer.parseInt(inputEntity1.getCoronaCheck1()) +
												Integer.parseInt(inputEntity1.getCoronaCheck2()) +
												Integer.parseInt(inputEntity1.getCoronaCheck3()) +
												Integer.parseInt(inputEntity1.getCoronaCheck4()) +
												Integer.parseInt(inputEntity1.getCoronaCheck5()) +
												Integer.parseInt(inputEntity1.getCoronaCheck6()) );
			if( userDairyReportDataDto.getTotaleValuationPoint() >= 16) {
				userDairyReportDataDto.setTotaleValuationComment("コロナ対策バッチリ！！");
			} else if (userDairyReportDataDto.getTotaleValuationPoint() >= 12) {
				userDairyReportDataDto.setTotaleValuationComment("結構やるじゃん？");
			} else if (userDairyReportDataDto.getTotaleValuationPoint() >= 8) {
				userDairyReportDataDto.setTotaleValuationComment("もうすこし頑張ろう！！");
			} else if (userDairyReportDataDto.getTotaleValuationPoint() >= 4) {
				userDairyReportDataDto.setTotaleValuationComment("対策が不十分です…");
			} else {
				userDairyReportDataDto.setTotaleValuationComment("非常に危険です！！");
			}

			//add漏れ
			list.add(userDairyReportDataDto);

		}
		//【確認用】
		//System.out.println("[UserDairyReportService]list.size() => " + list.size());

		return list;
	}

}
