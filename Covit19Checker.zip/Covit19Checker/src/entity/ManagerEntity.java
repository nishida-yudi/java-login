package entity;

import java.io.Serializable;

/**
 * 管理者エンティティ
 */
public class ManagerEntity implements Serializable {
	private Integer id;
	private String loginId;
	private String loginPassword;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getLoginPassword() {
		return loginPassword;
	}
	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}
}
