package servlet.userRegist;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dto.UserRegistDto;
import service.UserCheckService;

/**
 * Servlet implementation class UserRegistServlet
 */
@WebServlet("/UserRegistServlet")
public class UserRegistServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String loginId = request.getParameter("loginId");
		String loginPassword = request.getParameter("loginPassword");
		String usersName = request.getParameter("usersName");
		String temperatureIntegerNumber = request.getParameter("temperatureIntegerNumber");
		String temperatureSmallNumber = request.getParameter("temperatureSmallNumber");
		String className = request.getParameter("className");

		UserRegistDto userRegistDto = new UserRegistDto();


		StringBuilder buf = new StringBuilder();
		buf.append(temperatureIntegerNumber);
		buf.append(".");
		buf.append(temperatureSmallNumber);
		String normalTemperature = buf.toString();


		userRegistDto.setLoginId(loginId);
		userRegistDto.setLoginPassword(loginPassword);
		userRegistDto.setUsersName(usersName);
		userRegistDto.setNormalTemperature(normalTemperature);
		userRegistDto.setClassName(className);

		request.setAttribute("userRegistDto",userRegistDto );

		List<String> errorMessage = new ArrayList<String>();
		if(userRegistDto.getLoginId().length()==0) {
			errorMessage.add("ログインIDを入力してください");
			}
			 if(userRegistDto.getLoginPassword().length()==0) {
				 errorMessage.add("パスワードを入力してください");
			 }
			 if(userRegistDto.getLoginId().length()<5 || userRegistDto.getLoginId().length()>10) {
				 errorMessage.add( "ログインIDは5～10桁の半角英数字で入力してくだい。");
			 }
			 if(userRegistDto.getLoginPassword().length()<4 || userRegistDto.getLoginPassword().length()>8) {
				 errorMessage.add("パスワードは4〜8桁の半角英数字で入力してくだい。");
			}
			 if(userRegistDto.getUsersName().length()==0) {
				 errorMessage.add("名前を入力してください");
			 }
			 if(userRegistDto.getNormalTemperature().length()==0) {
				 errorMessage.add("あなたの平熱を入力してください");
			 }
			 if( errorMessage.size()>=1) {
				request.setAttribute("errorMessage",errorMessage );
				RequestDispatcher dispatcher = request.getRequestDispatcher("public/userRegist.jsp");
				dispatcher.forward(request, response);
				 return;
			}


			 UserCheckService userCheckService = new UserCheckService();
			 List<String> message =userCheckService.checkInput(userRegistDto);


			 if( message.size()>=1) {
					request.setAttribute("message",message );
					RequestDispatcher dispatcher = request.getRequestDispatcher("public/userRegist.jsp");
					dispatcher.forward(request, response);
					 return;
			}


		RequestDispatcher dispatcher = request.getRequestDispatcher("public/userRegistConfirm.jsp");
		dispatcher.forward(request, response);
	}

}
