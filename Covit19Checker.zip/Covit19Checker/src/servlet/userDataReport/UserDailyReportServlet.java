package servlet.userDataReport;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import constant.Constant;
import dto.CreateTargetDto;
import dto.UserDairyReportDataDto;
import entity.UserEntity;
import service.UserDairyReportService;

/**
 * Servlet implementation class UserDailyReportServlet
 */
@WebServlet("/user/UserDailyReportServlet")
public class UserDailyReportServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		CreateTargetDto createTargetDto = new CreateTargetDto();

		//リクエストスコープから、入力日を取得
		String targetYMD = (String) request.getAttribute("inputDay");

		//【確認用】
		//System.out.println("[UserDailyReportServlet]request.getAttribute(\"inputDay\") =>" + request.getAttribute("inputDay"));
		//System.out.println("[UserDailyReportServlet]リクエストスコープ targetYMD =>" + targetYMD);

		//リクエストスコープが存在しない(ユーザーメニュー画面からの遷移)場合
		if (targetYMD == null) {
			//リクエストパラメータから日付を取得する。
			//targetYMD = request.getParameter("date"); //NG
			targetYMD = request.getParameter("inputDay");
		}

		//追加
		if (targetYMD == null || targetYMD == "") {
			//リクエストスコープにエラーメッセージをセット
			request.setAttribute("errorMessage", "表示日が未入力です");
			//管理者メニューへ遷移
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("/WEB-INF/userMenu.jsp");
			requestDispatcher.forward(request, response);
			return;
		}

		//【確認用】
		//System.out.println("[UserDailyReportServlet]リクエストパラメータ targetYMD =>" + targetYMD);

		//セッションスコープからログイン情報を取得する。
		HttpSession session = request.getSession();
		UserEntity userEntity = (UserEntity) session.getAttribute(Constant.SESSION_KEY_LOGIN_INFO);
		String loginId = userEntity.getLoginId();

		//【確認用】
		//System.out.println("[UserDailyReportServlet]loginId=>" + loginId);

		//CreateTargetDtoにユーザー日別レポートの作成対象情報を格納する。
		createTargetDto.setLoginId(loginId);
		createTargetDto.setTargetYMD(targetYMD);

		//【確認用】
		//System.out.println("[UserDailyReportServlet]loginId=>" + loginId);
		//System.out.println("[UserDailyReportServlet] =>" + targetYMD);

		//ユーザー日別レポートサービスの日別レポートデータ作成を呼び出す。
		UserDairyReportService userDairyReportService = new UserDairyReportService();
		List<UserDairyReportDataDto> list = userDairyReportService.createDairyReportData(createTargetDto);

		//【確認用】
		//System.out.println("[UserDailyReportServlet]list.size() => " + list.size());
		//for (UserDairyReportDataDto userDairyReportDataDto : list) {
			//System.out.println("[UserDailyReportServlet]getComment1() => " + userDairyReportDataDto.getComment1());
			//System.out.println("[UserDailyReportServlet]getCoronaCheck1() => " + userDairyReportDataDto.getCoronaCheck1());
			//System.out.println("[UserDailyReportServlet]getgetInputDay() => " + userDairyReportDataDto.getInputDay());
			//System.out.println("[UserDailyReportServlet]getTotaleValuationPoint() => " + userDairyReportDataDto.getTotaleValuationPoint());
			//System.out.println("[UserDailyReportServlet]getTotaleValuationComment() => " + userDairyReportDataDto.getTotaleValuationComment());
		//}


		//日別状況レポートリスト ≠　0件の場合
		if(list.size() != 0) {
			// 戻り値をリクエストスコープに保存する。
			request.setAttribute("userDairyReportDataDtoList", list);
			// 日別状況画面（UserDailyReport.jsp）に遷移する。
			RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/userDailyReport.jsp");
			dispatcher.forward(request, response);
			return;
		} else {
			//日別状況レポートリスト =　0件の場合、「該当なし」の画面に遷移する
			//response.sendRedirect(request.getContextPath()+"/WEB-INF/userZeroUserDailyReport.jsp");
			RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/userZeroUserDailyReport.jsp");
			dispatcher.forward(request, response);
			return;
		}
	}

}
