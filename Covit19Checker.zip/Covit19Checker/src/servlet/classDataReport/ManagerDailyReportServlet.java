package servlet.classDataReport;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dto.ClassDataDto;
import dto.InputDto;
import dto.ManagerDailyReportDto;
import dto.UnansweredDto;
import service.ManagerDailyReportService;

/**
 * 日別照会サーブレット
 */
@WebServlet("/manager/ManagerDailyReportServlet")
public class ManagerDailyReportServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		ManagerDailyReportDto managerDailyReportDto = new ManagerDailyReportDto();

		//リクエストパラメータ取得
		String inputDay =  request.getParameter("inputDay");

		//リクエストパラメータ入力チェック
		if(inputDay == "" || inputDay == null) {

			//リクエストスコープにエラーメッセージをセット
			request.setAttribute("errorMessage", "表示日が未入力です");

			//管理者メニューへ遷移
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("/WEB-INF/managerMenu.jsp");
			requestDispatcher.forward(request, response);
			return;

		} else {
			//dtoに表示日をセット
			managerDailyReportDto.setInputDay(inputDay);
		}



		//サービスの呼び出し
		ManagerDailyReportService managerDailyReportService = new ManagerDailyReportService();

		List<InputDto> list1 = managerDailyReportService.checkInputDay1(managerDailyReportDto);

		//要素がない場合にTRUEを返す
		if(list1.isEmpty()) {

			//【確認用】
			//System.out.println("該当なし画面へ遷移");

			//日別状況（該当なし）へ遷移
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("/WEB-INF/classZeroDailyReport.jsp");
			requestDispatcher.forward(request, response);
			return;

		} else {

			List<UnansweredDto> list2 = managerDailyReportService.checkInputDay2();
			List<ClassDataDto>  list3 = managerDailyReportService.checkInputDay3();

			//リクエストスコープに保存
			request.setAttribute("InputDtoList", list1);
			request.setAttribute("UnansweredDtoList", list2);
			request.setAttribute("ClassDataDtoList", list3);

//			//【確認用】
//			System.out.println("*********************************************");
//			System.out.println("--- ▼[servlet] list1 ------------------");
//			System.out.println("list1.size() = " + list1.size());
//			for (InputDto inputDto : list1) {
//				System.out.println("inputDto.getCoronaRisk() =>" + inputDto.getCoronaRisk());
//				System.out.println("inputDto.getInputMember() =>" + inputDto.getInputMember());
//				System.out.println("inputDto.getTemperature() =>" + inputDto.getTemperature());
//			}
//			System.out.println("--- ▼[servlet] list2 ------------------");
//			System.out.println("list2.size() = " + list2.size());
//			for (UnansweredDto unansweredDto : list2) {
//				System.out.println("unansweredDto.getUnansweredName() =>" + unansweredDto.getUnansweredName());
//				System.out.println("unansweredDto.getNumberOfUnanserd() =>" + unansweredDto.getNumberOfUnanserd());
//			}
//
//			System.out.println("--- ▼[servlet] list3 ------------------");
//			System.out.println("list3.size() = " + list3.size());
//			for (ClassDataDto classDataDto : list3) {
//				System.out.println(classDataDto.getClassName());
//				System.out.println(classDataDto.getInputDay());
//				System.out.println(classDataDto.getNumberOfMenbers());
//			}
//			System.out.println("*********************************************");

			//日別状況（クラス）へ遷移
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("/WEB-INF/classDailyReport.jsp");
			requestDispatcher.forward(request, response);
			return;


		}

	}

}
