create table input(
	id		   serial,
	users_id   integer,
	input_day  date,
  	temperature  char(4),
  	corona_check1  char(1),
  	corona_check2  char(1),
  	corona_check3  char(1),
  	corona_check4  char(1),
  	corona_check5  char(1),
  	corona_check6  char(1),
  	primary key(id)
);