package service;

import dao.UsersDao;
import entity.UserRegistEntity;
import util.Util;

/**
 * ユーザサービス
 */
public class TestService {


	public void search(UserRegistEntity condition) {
		UsersDao usersDao = new UsersDao();
		UserRegistEntity userRegistEntity = new UserRegistEntity();
		userRegistEntity.setLoginId(condition.getLoginId());
		String passwordMd5 = Util.digest(condition.getLoginPassword());
		userRegistEntity.setLoginPassword(passwordMd5);
		userRegistEntity.setLoginPassword(condition.getLoginPassword());
		userRegistEntity.setUsersName(condition.getUsersName());
		userRegistEntity.setNormalTemperature(condition.getNormalTemperature());
		userRegistEntity.setClassName(condition.getClassName());
		userRegistEntity.setDropoutFlag(condition.getDropoutFlag());

		usersDao.registUser(userRegistEntity);
	}
}


