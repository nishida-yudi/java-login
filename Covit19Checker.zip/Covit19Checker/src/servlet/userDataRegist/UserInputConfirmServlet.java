package servlet.userDataRegist;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dto.UserInformationDto;

/**
 * Servlet implementation class UserConfirmationServlet
 */
@WebServlet("/user/UserInputConfirmServlet")
public class UserInputConfirmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;



	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//UserInformationDtoのインスタンス生成
		UserInformationDto userInformationDto = new UserInformationDto();

		//リクエストパラメータから値を取得
		confirm(request, userInformationDto);

		//リクエストスコープにuserInformationDtoの値を保存する。
		request.setAttribute("userInformationDto", userInformationDto);

		//体温・コロナチェック確認画面へ遷移する。
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/userInputConfirm.jsp");
		dispatcher.forward(request, response);
	}



	public void confirm(HttpServletRequest request, UserInformationDto userInformationDto) {
		String temperatureIntegerNumber = request.getParameter("temperatureIntegerNumber");
		String temperatureSmallNumber = request.getParameter("temperatureSmallNumber");
		String checkItem1 = request.getParameter("checkItem1");
		String checkItem2 = request.getParameter("checkItem2");
		String checkItem3 = request.getParameter("checkItem3");
		String checkItem4 = request.getParameter("checkItem4");;
		String checkItem5 = request.getParameter("checkItem5");;
		String checkItem6 = request.getParameter("checkItem6");;
		String checkItem7 = request.getParameter("checkItem7");;
		String checkItem8 = request.getParameter("checkItem8");;
		String checkItem9 = request.getParameter("checkItem9");;
		String checkItem10 = request.getParameter("checkItem10");;
		String checkItem11 = request.getParameter("checkItem11");;
		String checkItem12 = request.getParameter("checkItem12");;
		String checkItem13 = request.getParameter("checkItem13");;
		String checkItem14 = request.getParameter("checkItem14");;
		String checkItem15 = request.getParameter("checkItem15");;
		String checkItem16 = request.getParameter("checkItem16");;
		String checkItem17 = request.getParameter("checkItem17");;
		String checkItem18 = request.getParameter("checkItem18");;

		//体温の整数値と少数値を結合する。
//		StringBuilder buf = new StringBuilder();
//		buf.append(temperatureIntegerValue);
//		buf.append(".");
//		buf.append(temperatureSmallNumber);
//		String temperature = buf.toString();
		String temperature = temperatureIntegerNumber + "." + temperatureSmallNumber;
		//UserInformationDtoに格納する。
		userInformationDto.setTemperatureIntegerNumber(temperatureIntegerNumber);
		userInformationDto.setTemperatureSmallNumber(temperatureSmallNumber);
		userInformationDto.setTemperature(temperature);
		userInformationDto.setCheckItem1(checkItem1);
		userInformationDto.setCheckItem2(checkItem2);
		userInformationDto.setCheckItem3(checkItem3);
		userInformationDto.setCheckItem4(checkItem4);
		userInformationDto.setCheckItem5(checkItem5);
		userInformationDto.setCheckItem6(checkItem6);
		userInformationDto.setCheckItem7(checkItem7);
		userInformationDto.setCheckItem8(checkItem8);
		userInformationDto.setCheckItem9(checkItem9);
		userInformationDto.setCheckItem10(checkItem10);
		userInformationDto.setCheckItem11(checkItem11);
		userInformationDto.setCheckItem12(checkItem12);
		userInformationDto.setCheckItem13(checkItem13);
		userInformationDto.setCheckItem14(checkItem14);
		userInformationDto.setCheckItem15(checkItem15);
		userInformationDto.setCheckItem16(checkItem16);
		userInformationDto.setCheckItem17(checkItem17);
		userInformationDto.setCheckItem18(checkItem18);
	}

}
