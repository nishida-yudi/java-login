package dto;

import java.io.Serializable;

public class UnansweredDto implements Serializable {

	private Integer numberOfUnanserd;	//未回答者数
	private String UnansweredName;	//未解答者名

	public Integer getNumberOfUnanserd() {
		return numberOfUnanserd;
	}
	public void setNumberOfUnanserd(Integer numberOfUnanserd) {
		this.numberOfUnanserd = numberOfUnanserd;
	}


	public String getUnansweredName() {
		return UnansweredName;
	}
	public void setUnansweredName(String unansweredName) {
		UnansweredName = unansweredName;
	}

}
