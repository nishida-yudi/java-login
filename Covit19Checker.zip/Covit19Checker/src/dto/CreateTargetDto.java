package dto;

public class CreateTargetDto {

	private String loginId;
	private String targetYMD;
	private int usersId;

	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getTargetYMD() {
		return targetYMD;
	}
	public void setTargetYMD(String targetYMD) {
		this.targetYMD = targetYMD;
	}
	public int getUsersId() {
		return usersId;
	}
	public void setUsersId(int usersId) {
		this.usersId = usersId;
	}
}
