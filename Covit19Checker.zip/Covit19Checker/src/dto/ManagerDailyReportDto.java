package dto;

public class ManagerDailyReportDto {

	private String inputDay;	//入力日付

	public String getInputDay() {
		return inputDay;
	}

	public void setInputDay(String inputDay) {
		this.inputDay = inputDay;
	}

}
