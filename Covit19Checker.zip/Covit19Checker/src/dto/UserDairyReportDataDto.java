package dto;

import java.io.Serializable;

public class UserDairyReportDataDto implements Serializable {

	private String loginId;
	private String usersName;
	private String normalTemperature;
	private String targetYMD;
	private String inputDay;
	private String temperature;
	private int coronaCheck1;
	private String comment1;
	private int coronaCheck2;
	private String comment2;
	private int coronaCheck3;
	private String comment3;
	private int coronaCheck4;
	private String comment4;
	private int coronaCheck5;
	private String comment5;
	private int coronaCheck6;
	private String comment6;
	private int totaleValuationPoint;
	private String totaleValuationComment;

	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getUsersName() {
		return usersName;
	}
	public void setUsersName(String usersName) {
		this.usersName = usersName;
	}
	public String getNormalTemperature() {
		return normalTemperature;
	}
	public void setNormalTemperature(String normalTemperature) {
		this.normalTemperature = normalTemperature;
	}
	public String getTargetYMD() {
		return targetYMD;
	}
	public void setTargetYMD(String targetYMD) {
		this.targetYMD = targetYMD;
	}
	public String getInputDay() {
		return inputDay;
	}
	public void setInputDay(String inputDay) {
		this.inputDay = inputDay;
	}
	public String getTemperature() {
		return temperature;
	}
	public void setTemperature(String temperature) {
		this.temperature = temperature;
	}
	public int getCoronaCheck1() {
		return coronaCheck1;
	}
	public void setCoronaCheck1(int coronaCheck1) {
		this.coronaCheck1 = coronaCheck1;
	}
	public String getComment1() {
		return comment1;
	}
	public void setComment1(String comment1) {
		this.comment1 = comment1;
	}
	public int getCoronaCheck2() {
		return coronaCheck2;
	}
	public void setCoronaCheck2(int coronaCheck2) {
		this.coronaCheck2 = coronaCheck2;
	}
	public String getComment2() {
		return comment2;
	}
	public void setComment2(String comment2) {
		this.comment2 = comment2;
	}
	public int getCoronaCheck3() {
		return coronaCheck3;
	}
	public void setCoronaCheck3(int coronaCheck3) {
		this.coronaCheck3 = coronaCheck3;
	}
	public String getComment3() {
		return comment3;
	}
	public void setComment3(String comment3) {
		this.comment3 = comment3;
	}
	public int getCoronaCheck4() {
		return coronaCheck4;
	}
	public void setCoronaCheck4(int coronaCheck4) {
		this.coronaCheck4 = coronaCheck4;
	}
	public String getComment4() {
		return comment4;
	}
	public void setComment4(String comment4) {
		this.comment4 = comment4;
	}
	public int getCoronaCheck5() {
		return coronaCheck5;
	}
	public void setCoronaCheck5(int coronaCheck5) {
		this.coronaCheck5 = coronaCheck5;
	}
	public String getComment5() {
		return comment5;
	}
	public void setComment5(String comment5) {
		this.comment5 = comment5;
	}
	public int getCoronaCheck6() {
		return coronaCheck6;
	}
	public void setCoronaCheck6(int coronaCheck6) {
		this.coronaCheck6 = coronaCheck6;
	}
	public String getComment6() {
		return comment6;
	}
	public void setComment6(String comment6) {
		this.comment6 = comment6;
	}
	public int getTotaleValuationPoint() {
		return totaleValuationPoint;
	}
	public void setTotaleValuationPoint(int totaleValuationPoint) {
		this.totaleValuationPoint = totaleValuationPoint;
	}
	public String getTotaleValuationComment() {
		return totaleValuationComment;
	}
	public void setTotaleValuationComment(String totaleValuationComment) {
		this.totaleValuationComment = totaleValuationComment;
	}
}
