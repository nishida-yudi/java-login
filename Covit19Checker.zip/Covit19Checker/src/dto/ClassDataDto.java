package dto;

import java.io.Serializable;

public class ClassDataDto implements Serializable {

	private String inputDay;		//入力日付
	private String className;		//クラス名
	//private Integer numberOfMenbers;	//人数
	private String numberOfMenbers;	//人数


	public String getInputDay() {
		return inputDay;
	}
	public void setInputDay(String inputDay) {
		this.inputDay = inputDay;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
//	public Integer getNumberOfMenbers() {
//		return numberOfMenbers;
//	}
//	public void setNumberOfMenbers(Integer numberOfMenbers) {
//		this.numberOfMenbers = numberOfMenbers;
//	}
	public String getNumberOfMenbers() {
		return numberOfMenbers;
	}
	public void setNumberOfMenbers(Integer numberOfMenbers) {
		this.numberOfMenbers = numberOfMenbers.toString();
	}



}
