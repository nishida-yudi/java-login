create table users(
	id		   serial,
	login_id   varchar(10),
	login_password  char(32),
  	users_name  varchar(50),
  	normal_temperature  char(4),
  	class_name  varchar(100),
  	dropout_flag	char(1),
  	primary key(id)
);