package filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import constant.Constant;
import entity.ManagerEntity;

/**
 * 認証処理フィルタ
 */
public class ManagerAuthenticationFilter implements Filter {
	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain chain) throws IOException, ServletException {
		System.out.println("AuthenticationFilter.doFilter() start");
		HttpServletRequest request = (HttpServletRequest)servletRequest;
		HttpServletResponse response = (HttpServletResponse)servletResponse;
		//認証対象のチェック
		String contextPath = request.getContextPath();
		String target = request.getRequestURI().replaceFirst(contextPath, "");

		System.out.println("target => " + target);

		if(!(target.startsWith(Constant.PUBLIC_URL_PREFIX_PUBLIC)
				|| target.startsWith(Constant.PUBLIC_URL_PREFIX_STATIC))) {
			System.out.println("認証処理実行");
			//ログインチェックをする
			HttpSession session = request.getSession();
			ManagerEntity managerEntity = (ManagerEntity) session.getAttribute(Constant.SESSION_KEY_LOGIN_INFO);
			if (managerEntity == null) {
				//ログインしてない場合はログイン画面へ遷移
				response.sendRedirect(request.getContextPath() + Constant.PUBLIC_URL_PREFIX_PUBLIC + "top.jsp");
				return;
			}
		} else {
			System.out.println("認証処理スキップ");
		}

		//次のフィルタを実行する
		chain.doFilter(request, response);

		//■フィルタ・サーブレット実行後の処理
		System.out.println("AuthenticationFilter.doFilter() end");
	}


}
