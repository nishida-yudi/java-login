package service;

import dao.InputDao;
import dto.RegistDto;

public class UserCalculationService {

	public void calculation(RegistDto registDto) {

		//チェック項目１～１８を３項目ずつの６グループに分け、それぞれのデータを計算し設定する。

		//コロナチェック項目1

		System.out.println("registDto.getCheckItem1() => " + registDto.getCheckItem1());
		 int ch1 = Integer.parseInt(registDto.getCheckItem1()) +
				  Integer.parseInt(registDto.getCheckItem2()) +
				  Integer.parseInt(registDto.getCheckItem3()) ;
		String corona_check1 = String.valueOf(ch1);

		//コロナチェック項目2
		int ch2 = Integer.parseInt(registDto.getCheckItem4()) +
				  Integer.parseInt(registDto.getCheckItem5()) +
				  Integer.parseInt(registDto.getCheckItem6()) ;
		String corona_check2 = String.valueOf(ch2);

		//コロナチェック項目3
		int ch3 = Integer.parseInt(registDto.getCheckItem7()) +
				  Integer.parseInt(registDto.getCheckItem8()) +
				  Integer.parseInt(registDto.getCheckItem9()) ;
		String corona_check3 = String.valueOf(ch3);

		//コロナチェック項目4
		int ch4 = Integer.parseInt(registDto.getCheckItem10()) +
				  Integer.parseInt(registDto.getCheckItem11()) +
				  Integer.parseInt(registDto.getCheckItem12()) ;
		String corona_check4 = String.valueOf(ch4);

		//コロナチェック項目5
		int ch5 = Integer.parseInt(registDto.getCheckItem13()) +
				  Integer.parseInt(registDto.getCheckItem14()) +
				  Integer.parseInt(registDto.getCheckItem15()) ;
		String corona_check5 = String.valueOf(ch5);

		//コロナチェック項目6
		int ch6 = Integer.parseInt(registDto.getCheckItem16()) +
				  Integer.parseInt(registDto.getCheckItem17()) +
				  Integer.parseInt(registDto.getCheckItem18()) ;
		String corona_check6 = String.valueOf(ch6);

		//コロナチェック項目1〜6をRegistDtoに格納する。
		registDto.setCorona_check1(corona_check1);
		registDto.setCorona_check2(corona_check2);
		registDto.setCorona_check3(corona_check3);
		registDto.setCorona_check4(corona_check4);
		registDto.setCorona_check5(corona_check5);
		registDto.setCorona_check6(corona_check6);


		//System.out.println("registDto.getCorona_check1() =>" + registDto.getCorona_check1());

		//入力データDaoを呼び出し、入力データテーブルへ入力値を登録する。
		InputDao inputDao = new InputDao();
		inputDao.regist(registDto);
	}

}
