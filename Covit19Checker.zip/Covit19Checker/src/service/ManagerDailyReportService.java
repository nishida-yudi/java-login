package service;

import java.util.ArrayList;
import java.util.List;

import dao.InputDao;
import dao.UsersDao;
import dto.ClassDataDto;
import dto.InputDto;
import dto.ManagerDailyReportDto;
import dto.UnansweredDto;
import entity.InputEntity;
import entity.UserEntity;

public class ManagerDailyReportService {

	InputDao inputDao = new InputDao();
	UsersDao usersDao = new UsersDao();

	//list追加フラグ
	String listAddFlag = "0";		//0:addしない 1:addする

	//ClassDataDto用
	String ClassDataDtoInputDay = ""; 		//入力日付
	String ClassDataDtoClassName = "";		//クラス名
	int ClassDataDtoNumberOfMenbers = 0; 	//人数

	//UnansweredDto用
	int numberOfUnAnserd = 0;	//未回答者数
	List<String> answeredNameList = new ArrayList<String>(); //解答者名
	String answeredName ="";		//解答者名(退避用）


	//1)入力データリスト作成
	public List<InputDto> checkInputDay1(ManagerDailyReportDto managerDailyReportDto) {


		//戻り値
		//InputDto inputDto = new InputDto(); //NG
		//個々にインスタンスを作成しないとダメ（参照先が同じ＝list内全て同じデータ（最後のデータ））


		List<InputDto> list = new ArrayList<InputDto>();

		//入力データテーブルより引数（入力日付）のデータを取得し、リストに格納
		List<InputEntity> inputDbList = inputDao.findInputDay(managerDailyReportDto);

		//ユーザーテーブルより退校フラグ＝０（在校）のデータを取得し、リストに格納
		List<UserEntity> usersDbList = usersDao.getUser();

		//UnansweredDto用
		List<String> nameList = new ArrayList<String>();

		if(inputDbList.size() >= 1 ) {

			for (InputEntity inputEntity : inputDbList) {

				InputDto inputDto = new InputDto();

				//体温
				inputDto.setTemperature(inputEntity.getTemperature());

				//入力メンバー名
				for (UserEntity userEntity : usersDbList) {
					if( inputEntity.getUsersId().equals(userEntity.getId()) ) {

						inputDto.setInputMember(userEntity.getUsersName());

						//UnansweredDto用データ退避 回答者名
						answeredName = userEntity.getUsersName();

						listAddFlag = "1";		//addする

						break;
					}
				}

				//コロナ危険度
				int riskScore = Integer.parseInt(inputEntity.getCoronaCheck1()) +
								Integer.parseInt(inputEntity.getCoronaCheck2()) +
								Integer.parseInt(inputEntity.getCoronaCheck3()) +
								Integer.parseInt(inputEntity.getCoronaCheck4()) +
								Integer.parseInt(inputEntity.getCoronaCheck5()) +
								Integer.parseInt(inputEntity.getCoronaCheck6()) ;

				if( riskScore >= 16) {
					inputDto.setCoronaRisk("コロナ対策バッチリ！！");
				} else if (riskScore >= 12) {
					inputDto.setCoronaRisk("結構やるじゃん？");
				} else if (riskScore >= 8) {
					inputDto.setCoronaRisk("もうすこし頑張ろう！！");
				} else if (riskScore >= 4) {
					inputDto.setCoronaRisk("対策が不十分です…");
				} else {
					inputDto.setCoronaRisk("非常に危険です！！");
				}

				if(listAddFlag.equals("1")) {

					list.add(inputDto);
					//UnansweredDto用データ退避 回答者名
					nameList.add(answeredName);

					listAddFlag = "0";	//addしない
				}

//				//【確認用】
//				System.out.println("[service] inputDto.getTemperature():" + inputDto.getTemperature());
//				System.out.println("[service] inputDto.getInputMember():" + inputDto.getInputMember());
//				System.out.println("[service] inputDto.getCoronaRisk():" + inputDto.getCoronaRisk());
//				System.out.println("==============================================");
			}

			//ClassDataDto用データ退避
			this.ClassDataDtoInputDay = managerDailyReportDto.getInputDay(); 	//入力日付
			this.ClassDataDtoNumberOfMenbers = usersDbList.size(); 				//人数
			UserEntity entity =  usersDbList.get(0);
			this.ClassDataDtoClassName = entity.getClassName();					//クラス名
			//UnansweredDto用データ退避
			this.numberOfUnAnserd = this.ClassDataDtoNumberOfMenbers - list.size();	//未回答者数
			this.answeredNameList = nameList; //解答者名

			return list;

		} else {
			return list;
		}


	}

	// 2)未回答者リスト作成
	public List<UnansweredDto> checkInputDay2() {
		//戻り値
		List<UnansweredDto> list = new ArrayList<UnansweredDto>();


		//ユーザーテーブルより退校フラグ＝０（在校）のデータを取得し、リストに格納
		List<UserEntity> usersDbList = usersDao.getUser();

//		//【確認用】
//		System.out.println("[Service] usersDbList.size() :" + usersDbList.size());
//		System.out.println("[Service] answeredNameList.size() :" + answeredNameList.size());

		for (UserEntity userEntity : usersDbList) {

			if( !(answeredNameList.contains(userEntity.getUsersName())) ) {

				UnansweredDto unAnsweredDto = new UnansweredDto();

				unAnsweredDto.setNumberOfUnanserd(this.numberOfUnAnserd); 		//未回答者数

				unAnsweredDto.setUnansweredName(userEntity.getUsersName());		//未回答者名

				list.add(unAnsweredDto);

//				//【確認用】
//				System.out.println("[Service] unAnsweredDto.getUnansweredName :" + unAnsweredDto.getUnansweredName());
//				System.out.println("[Service] unAnsweredDto.getNumberOfUnanserd() :" + unAnsweredDto.getNumberOfUnanserd());

			}
		}

		return list;
	}

	// 3)クラス情報リスト作成
	public List<ClassDataDto> checkInputDay3() {
		//戻り値
		ClassDataDto classDataDto = new ClassDataDto();
		List<ClassDataDto> list = new ArrayList<ClassDataDto>();

		classDataDto.setInputDay(ClassDataDtoInputDay);					//入力日付
		classDataDto.setClassName(ClassDataDtoClassName);				//クラス名
		classDataDto.setNumberOfMenbers(ClassDataDtoNumberOfMenbers);	//人数
		list.add(classDataDto);

		return list;

	}




}
