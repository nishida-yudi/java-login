package entity;

import java.io.Serializable;

/**
 * 入力データエンティティ
 */
public class InputEntity implements Serializable {
	private Integer id;
	private Integer usersId;
	private String inputDay;
	private String temperature;
	private String coronaCheck1;
	private String coronaCheck2;
	private String coronaCheck3;
	private String coronaCheck4;
	private String coronaCheck5;
	private String coronaCheck6;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getUsersId() {
		return usersId;
	}
	public void setUsersId(Integer usersId) {
		this.usersId = usersId;
	}
	public String getInputDay() {
		return inputDay;
	}
	public void setInputDay(String inputDay) {
		this.inputDay = inputDay;
	}
	public String getTemperature() {
		return temperature;
	}
	public void setTemperature(String temperature) {
		this.temperature = temperature;
	}
	public String getCoronaCheck1() {
		return coronaCheck1;
	}
	public void setCoronaCheck1(String coronaCheck1) {
		this.coronaCheck1 = coronaCheck1;
	}
	public String getCoronaCheck2() {
		return coronaCheck2;
	}
	public void setCoronaCheck2(String coronaCheck2) {
		this.coronaCheck2 = coronaCheck2;
	}
	public String getCoronaCheck3() {
		return coronaCheck3;
	}
	public void setCoronaCheck3(String coronaCheck3) {
		this.coronaCheck3 = coronaCheck3;
	}
	public String getCoronaCheck4() {
		return coronaCheck4;
	}
	public void setCoronaCheck4(String coronaCheck4) {
		this.coronaCheck4 = coronaCheck4;
	}
	public String getCoronaCheck5() {
		return coronaCheck5;
	}
	public void setCoronaCheck5(String coronaCheck5) {
		this.coronaCheck5 = coronaCheck5;
	}
	public String getCoronaCheck6() {
		return coronaCheck6;
	}
	public void setCoronaCheck6(String coronaCheck6) {
		this.coronaCheck6 = coronaCheck6;
	}
}
