package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import dto.CreateTargetDto;
import dto.UserRegistDto;
import entity.UserEntity;
import entity.UserRegistEntity;
import util.Util;

public class UsersDao {
	//ユーザー
	public List<UserEntity> findLoginId(UserEntity condition){

		List<UserEntity> list = new ArrayList<UserEntity>();

		try {
			Context initContext = new InitialContext();
			Context envContext = (Context)initContext.lookup("java:/comp/env");
			DataSource dataSource = (DataSource)envContext.lookup("jdbc/covit19_checker");
			Connection connection = dataSource.getConnection();

			String sql =
					  " select "
					+ "   id, "
					+ "   login_id, "
					+ "   login_password, "
					+ "   users_name, "
					+ "   normal_temperature, "
					+ "   class_name, "
					+ "   dropout_flag "
					+ " from "
					+ "   users "
					+ " where "
					+ "   login_id = ? "
					+ " and "
					+ "   login_password = ? "
					+ " ;";

			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, condition.getLoginId());
			preparedStatement.setString(2, condition.getLoginPassword());
			ResultSet resultSet = preparedStatement.executeQuery();

			while(resultSet.next()) {
				UserEntity userEntity = new UserEntity();
				if(resultSet.wasNull()) {
					userEntity.setId(null);
				}
				userEntity.setId(resultSet.getInt("id"));
				userEntity.setLoginId(resultSet.getString("login_id"));
				userEntity.setLoginPassword(resultSet.getString("login_password"));
				userEntity.setUsersName(resultSet.getString("users_name"));
				userEntity.setNormalTemperature(resultSet.getString("normal_temperature"));
				userEntity.setClassName(resultSet.getString("class_name"));
				userEntity.setDropoutFlag(resultSet.getString("dropout_flag"));

				list.add(userEntity);
			}
			connection.close();
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		}


		return list;

	}


	//ユーザー情報取得処理
	public List<UserEntity> getUser() {

		List<UserEntity> list = new ArrayList<UserEntity>();

		try {
			Context initContext = new InitialContext();
			Context envContext = (Context)initContext.lookup("java:/comp/env");
			DataSource dataSource = (DataSource)envContext.lookup("jdbc/covit19_checker");
			Connection connection = dataSource.getConnection();

			String sql = " select "
					+ "  id, "
					+ "	 login_id, "
					+ "	 users_name, "
					+ "	 normal_temperature  , "
					+ "	 class_name  , "
					+ "	 dropout_flag  "
					+ " from  "
					+ "	 users "
					+ " where "
					+ "	 class_name = ? "
					+ " and  "
					+ "	 dropout_flag = ? ;";

			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, "Java Webアプリ技術者育成科");
			preparedStatement.setString(2, "0"); 		//0:在校 1:退校
			ResultSet resultSet = preparedStatement.executeQuery();

			//List<UserEntity> list = new ArrayList<UserEntity>();
			while(resultSet.next()) {

				UserEntity userEntity = new UserEntity();

				userEntity.setId(resultSet.getInt("id"));

				if(resultSet.wasNull()) {
					userEntity.setId(null);
				}
				userEntity.setLoginId(resultSet.getString("login_id"));
				userEntity.setUsersName(resultSet.getString("users_name"));
				userEntity.setNormalTemperature(resultSet.getString("normal_temperature"));
				userEntity.setClassName(resultSet.getString("class_name"));
				list.add(userEntity);

			}

			connection.close(); //Contextに戻すイメージ

			return list;
			//検索結果＝０件　→　要素数０のlist を返す方が後の処理が書きやすい

		} catch (Exception e) {
			e.printStackTrace();
		}
		//return null;
		return list;
	}


	//クラス内ユーザ検索処理
	public List<UserEntity> findClassUsers(String condition) {

		List<UserEntity> list = new ArrayList<UserEntity>();

		try {
			Context initContext = new InitialContext();
			Context envContext = (Context)initContext.lookup("java:/comp/env");
			DataSource dataSource = (DataSource)envContext.lookup("jdbc/covit19_checker");
			Connection connection = dataSource.getConnection();

			String sql = " select "
					+ "  id, "
					+ "	 login_id, "
					+ "	 users_name, "
					+ "	 normal_temperature  , "
					+ "	 class_name  , "
					+ "	 dropout_flag  "
					+ " from  "
					+ "	 users "
					+ " where "
					+ "	 class_name = ? ; ";

			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, condition);
			ResultSet resultSet = preparedStatement.executeQuery();

			//List<UserEntity> list = new ArrayList<UserEntity>();
			while(resultSet.next()) {

				UserEntity userEntity = new UserEntity();

				userEntity.setId(resultSet.getInt("id"));

				if(resultSet.wasNull()) {
					userEntity.setId(null);
				}
				userEntity.setLoginId(resultSet.getString("login_id"));
				userEntity.setUsersName(resultSet.getString("users_name"));
				userEntity.setNormalTemperature(resultSet.getString("normal_temperature"));
				userEntity.setClassName(resultSet.getString("class_name"));
				userEntity.setDropoutFlag(resultSet.getString("dropout_flag"));
				list.add(userEntity);

			}

			connection.close(); //Contextに戻すイメージ

			return list;
			//検索結果＝０件　→　要素数０のlist を返す方が後の処理が書きやすい

		} catch (Exception e) {
			e.printStackTrace();
		}
		//return null;
		return list;
	}


	//ユーザデータ上書き処理
	public boolean overWriteUser(List<UserEntity> condition) {

		List<UserEntity> list = condition;

		try {
			Context initContext = new InitialContext();
			Context envContext = (Context)initContext.lookup("java:/comp/env");
			DataSource dataSource = (DataSource)envContext.lookup("jdbc/covit19_checker");
			Connection connection = dataSource.getConnection();

			// update users set dropout_flag = ? where  login_id = ? ;
			String sql =  " update "
					+ "   users "
					+ " set "
					+ "   dropout_flag = ? "
					+ " where "
					+ "   login_id = ? "
					+ " ;";

			//自動コミット無効
			connection.setAutoCommit(false);

			PreparedStatement preparedStatement = connection.prepareStatement(sql);

			for (UserEntity userEntity : list) {
				preparedStatement.setString(1, userEntity.getDropoutFlag());
				preparedStatement.setString(2, userEntity.getLoginId());
				int result = preparedStatement.executeUpdate();

				//更新結果
				if(result != 1) {
					//ロールバック
					connection.rollback();
					return false;
				}

//				if(result != 1) {
//					//ロールバック
//					connection.rollback();
//					return false;
//				} else {
//					//コミット処理（確定処理）
//					//connection.commit();
//				}
			}

			//コミット処理（確定処理）
			connection.commit();

			preparedStatement.close();
			connection.close();

			return true;

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		//return null;
	}
	//ユーザーデータ表示機能
	public List<UserEntity> findUsers(CreateTargetDto condition) {

		List<UserEntity> userList = new ArrayList<UserEntity>();

		try {
			Context initContext = new InitialContext();
			Context envContext = (Context)initContext.lookup("java:/comp/env");
			DataSource dataSource = (DataSource)envContext.lookup("jdbc/covit19_checker");
			Connection connection = dataSource.getConnection();

			String sql =
					  " select "
					+ "   id, "
					+ "   login_id, "
					+ "   login_password, "
					+ "   users_name, "
					+ "   normal_temperature, "
					+ "   class_name, "
					+ "   dropout_flag "
					+ " from "
					+ "   users "
					+ " where "
					+ "   login_id = ? "
					+ " ;";

			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, condition.getLoginId());
			ResultSet resultSet = preparedStatement.executeQuery();

			//List<UserEntity> userList = new ArrayList<UserEntity>();
			while(resultSet.next()) {
				UserEntity userEntity = new UserEntity();

				userEntity.setId(resultSet.getInt("id"));

				if(resultSet.wasNull()) {
					userEntity.setId(null);
				}
				userEntity.setLoginId(resultSet.getString("login_id"));
				//userEntity.setLoginPassword(resultSet.getString("login_password"));
				userEntity.setUsersName(resultSet.getString("users_name"));
				userEntity.setNormalTemperature(resultSet.getString("normal_temperature"));
				userEntity.setClassName(resultSet.getString("class_name"));
				userEntity.setDropoutFlag(resultSet.getString("dropout_flag"));
				userList.add(userEntity);
			}
			connection.close();
			return userList;
		} catch (Exception e) {
			e.printStackTrace();
		}

		//return null;
		return userList;
	}


		//ユーザー登録
	public void registUser(UserRegistEntity condition){

		try {
			Context initContext = new InitialContext();
			Context envContext = (Context)initContext.lookup("java:/comp/env");
			DataSource dataSource = (DataSource)envContext.lookup("jdbc/covit19_checker");
			Connection connection = dataSource.getConnection();

			String loginId =condition.getLoginId();
			String loginPassword =condition.getLoginPassword();
			String usersName =condition.getUsersName();
			String normalTemperature =condition.getNormalTemperature();
			String className =condition.getClassName();
			String dropoutFlag =condition.getDropoutFlag();


			String sql =
						"insert into users(login_id,"
						+ "login_password,"
						+ "users_name,"
						+ "normal_temperature,"
						+ "class_name,"
						+ "dropout_flag) values (?,?,?,?,?,?);";


			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, loginId);
			preparedStatement.setString(2, Util.digest(loginPassword));
			preparedStatement.setString(3, (usersName));
			preparedStatement.setString(4, (normalTemperature));
			preparedStatement.setString(5, (className));
			preparedStatement.setString(6, (dropoutFlag));
			preparedStatement.executeUpdate();



			connection.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//ユーザーID照合
		public static boolean usersRegist(UserRegistDto userRegistDto){


			try {
				Context initContext = new InitialContext();
				Context envContext = (Context)initContext.lookup("java:/comp/env");
				DataSource dataSource = (DataSource)envContext.lookup("jdbc/covit19_checker");
				Connection connection = dataSource.getConnection();

				String sql =
						  " select "
						+ "   id, "
						+ "   login_id, "
						+ "   login_password, "
						+ "   users_name, "
						+ "   normal_temperature, "
						+ "   class_name, "
						+ "   dropout_flag "
						+ " from "
						+ "   users "
						+ " ;";

				PreparedStatement preparedStatement = connection.prepareStatement(sql);
//				preparedStatement.setString(1, userRegistDto.getId());
				ResultSet resultSet = preparedStatement.executeQuery();

				while(resultSet.next()) {
					String loginId =resultSet.getString("login_id");
					String newloginId = userRegistDto.getLoginId();
					if(loginId.equals(newloginId)) {
						return true;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}


				return false;

		}

}
