insert into manager
	(login_id,login_password)
	values('mgr1234567', '4F70EB78D94C3BD73D65598E157DB364');