package servlet.login;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import constant.Constant;
import entity.ManagerEntity;
import service.ManagerService;

/**
 * Servlet implementation class UserLoginServlet
 */
@WebServlet("/ManagerLoginServlet")
public class ManagerLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String loginId = request.getParameter("loginId");
		String loginPassword = request.getParameter("loginPassword");

		ManagerService managerService = new ManagerService();

		ManagerEntity managerEntity = new ManagerEntity();
		managerEntity.setLoginId(loginId);
		managerEntity.setLoginPassword(loginPassword);


		List<String> errorMessage = new ArrayList<String>();
		if (loginId.length() == 0) {
			errorMessage.add("ログインIDを入力してください");
		}
		if (loginPassword.length() == 0) {
			errorMessage.add( "パスワードを入力してください");
		}


		if (errorMessage.size() >= 1) {
			request.setAttribute("errorMessage", errorMessage);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/public/managerLogin.jsp");
			dispatcher.forward(request, response);
			return;
		}

		List<ManagerEntity> managerList = managerService.searchManager(managerEntity);
		//if (managerList.size() == 0) {
		if (managerList.isEmpty()) {

			//ログイン画面へ遷移する
			request.setAttribute("errorMessage", "ログインIDまたはパスワードが違います");
			RequestDispatcher dispatcher = request.getRequestDispatcher("/public/managerLogin.jsp");
			dispatcher.forward(request, response);
			return;
		}

		HttpSession session = request.getSession();
		session.setAttribute(Constant.SESSION_KEY_LOGIN_INFO, managerList.get(0));
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/managerMenu.jsp");
		dispatcher.forward(request, response);
	}

 }
