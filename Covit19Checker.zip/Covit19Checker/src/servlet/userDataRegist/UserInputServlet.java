package servlet.userDataRegist;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import constant.Constant;
import dto.RegistDto;
import entity.UserEntity;
import service.UserCalculationService;


/**
 * Servlet implementation class UserRegistrationServlet
 */
@WebServlet("/user/UserInputServlet")
public class UserInputServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;



	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String action = request.getParameter("action");

		//RegistDtoのインスタンス生成
		RegistDto registDto = new RegistDto();

		//リクエストパラメータから値を取得
		regist(request, registDto);
		//リクエストスコープにregistDtoの値を保存する。
		request.setAttribute("registDto", registDto);

		//ユーザー入力確認画面で戻るをクリックした場合
		if(action.equals("back")) {
			//ユーザー入力画面へ遷移する
			RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/userInput.jsp");
			dispatcher.forward(request, response);
			return;
		}

		//セッションスコープから、ユーザーIDを取得する(要確認)。
		HttpSession session = request.getSession();
		UserEntity userEntity = (UserEntity) session.getAttribute(Constant.SESSION_KEY_LOGIN_INFO);
		Integer usersId = userEntity.getId();

		//入力日の日付を入手し、文字列型に変換
		Calendar cl = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	    String inputDay = sdf.format(cl.getTime());


	    //System.out.println("inputDay => " +inputDay);
	    //System.out.println("usersId => " + usersId);


	    //RegistDtoに、ユーザーID・入力日を格納する。
	    registDto.setUsersId(usersId);
	    registDto.setInputDay(inputDay);


	    //UserCalculationServiceクラスのインスタンスを生成しcalculationメソッドを実行する。
	    UserCalculationService usercalculationService = new UserCalculationService();
	    usercalculationService.calculation(registDto);

	    //日付をリクエストスコープに保存
	    request.setAttribute("inputDay", registDto.getInputDay());

	    //System.out.println("registDto.getInputDay() => " + registDto.getInputDay());
	    //System.out.println("registDto.getUsersId() => " + registDto.getUsersId());

	    //UserDailyReportServletへ遷移する
	    RequestDispatcher dispatcher = request.getRequestDispatcher("/user/UserDailyReportServlet");
		dispatcher.forward(request, response);
	}


	public void regist(HttpServletRequest request, RegistDto registDto) {
		String temperatureIntegerNumber = request.getParameter("temperatureIntegerNumber");
		String temperatureSmallNumber = request.getParameter("temperatureSmallNumber");
		String temperature = request.getParameter("temperature");
		String checkItem1 = request.getParameter("checkItem1");
		String checkItem2 = request.getParameter("checkItem2");
		String checkItem3 = request.getParameter("checkItem3");
		String checkItem4 = request.getParameter("checkItem4");;
		String checkItem5 = request.getParameter("checkItem5");;
		String checkItem6 = request.getParameter("checkItem6");;
		String checkItem7 = request.getParameter("checkItem7");;
		String checkItem8 = request.getParameter("checkItem8");;
		String checkItem9 = request.getParameter("checkItem9");;
		String checkItem10 = request.getParameter("checkItem10");;
		String checkItem11 = request.getParameter("checkItem11");;
		String checkItem12 = request.getParameter("checkItem12");;
		String checkItem13 = request.getParameter("checkItem13");;
		String checkItem14 = request.getParameter("checkItem14");;
		String checkItem15 = request.getParameter("checkItem15");;
		String checkItem16 = request.getParameter("checkItem16");;
		String checkItem17 = request.getParameter("checkItem17");;
		String checkItem18 = request.getParameter("checkItem18");;


		//RegistDtoに格納する。
		registDto.setTemperature(temperature);
		registDto.setTemperatureIntegerNumber(temperatureIntegerNumber);
		registDto.setTemperatureSmallNumber(temperatureSmallNumber);
		registDto.setCheckItem1(checkItem1);
		registDto.setCheckItem2(checkItem2);
		registDto.setCheckItem3(checkItem3);
		registDto.setCheckItem4(checkItem4);
		registDto.setCheckItem5(checkItem5);
		registDto.setCheckItem6(checkItem6);
		registDto.setCheckItem7(checkItem7);
		registDto.setCheckItem8(checkItem8);
		registDto.setCheckItem9(checkItem9);
		registDto.setCheckItem10(checkItem10);
		registDto.setCheckItem11(checkItem11);
		registDto.setCheckItem12(checkItem12);
		registDto.setCheckItem13(checkItem13);
		registDto.setCheckItem14(checkItem14);
		registDto.setCheckItem15(checkItem15);
		registDto.setCheckItem16(checkItem16);
		registDto.setCheckItem17(checkItem17);
		registDto.setCheckItem18(checkItem18);
	}

}
