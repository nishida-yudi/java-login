package servlet.classManagement;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import entity.UserEntity;
import service.UserListService;

/**
 * Servlet implementation class ClassManagementServlet
 */
@WebServlet("/manager/ClassManagementServlet")
public class ClassManagementServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		List<UserEntity> sessionUsersList = new ArrayList<UserEntity>();
		List<UserEntity> requestUsersList = new ArrayList<UserEntity>();
		List<UserEntity> serviceResultList = new ArrayList<UserEntity>();

		//■セッションスコープからユーザリストを取り出す。
		HttpSession session;
		session = request.getSession();
		List<UserEntity> usersList = (List<UserEntity> )session.getAttribute("userList");

		//【確認用】
		//System.out.println("[ClassManagementServlet]usersList.size()" + usersList.size());

		for (UserEntity userEntity : usersList) {
			sessionUsersList.add(userEntity);
		}

		//■リクエストスコープから要素を取り出す。
		List<String> requestNameList = new ArrayList<String>();
		List<String> requestDropOutFlagList = new ArrayList<String>();
		String[] name;
		String[] dropOutFlag;
		for (int i = 1; request.getParameter("userName" + i) != null; i++) {
			requestNameList.add(request.getParameter("userName" + i));
		}
		for (int i = 1; request.getParameter("dropoutFlag" + i) != null; i++) {
			requestDropOutFlagList.add(request.getParameter("dropoutFlag" + i));
		}


		if(requestNameList.size() == requestDropOutFlagList.size()) {
			name = requestNameList.toArray(new String[requestNameList.size()]);
			dropOutFlag = requestDropOutFlagList.toArray(new String[requestDropOutFlagList.size()]);
		} else {
			//リクエストスコープにエラーメッセージをセット
			request.setAttribute("errorMessage", "userNameとdropoutFlagの要素数が違います");
			//クラス管理画面へ遷移
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("/WEB-INF/classManagement.jsp");
			requestDispatcher.forward(request, response);
			return;
		}

		for (int i = 0; i < name.length; i++) {
			UserEntity userEntity = new UserEntity();
			userEntity.setUsersName(name[i]);
			userEntity.setDropoutFlag(dropOutFlag[i]);
			requestUsersList.add(userEntity);
			//【確認用】
			//System.out.println("[ClassManagementServlet] name.length => " + name.length);
			//System.out.println("[ClassManagementServlet] name[i] => " + name[i]);
			//System.out.println("[ClassManagementServlet] dropOutFlag[i] => " + dropOutFlag[i]);
		}

		//■ユーザリストデータ更新処理のユーザリストデータ更新処理メソッド使用
		UserListService userListService = new UserListService();

//		//【確認用】12 12
//		System.out.println("[ClassManagementServlet]sessionUsersList.size() =>" + sessionUsersList.size());
//		System.out.println("[ClassManagementServlet]requestUsersList.size() =>" + requestUsersList.size());

		serviceResultList = userListService.overwriteUserList(sessionUsersList , requestUsersList);

//		//【確認用】0
//		System.out.println("[ClassManagementServlet]serviceResultList.size()" + serviceResultList.size());

		//結果をセッションスコープに同名で保存（上書き）
		session.setAttribute("userList", serviceResultList);

		//変更確認画面へ遷移
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("/WEB-INF/classManagementConfirm.jsp");
		requestDispatcher.forward(request, response);
		return;



	}

}
