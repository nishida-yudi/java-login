package dto;

import java.io.Serializable;

public class UserInformationDto implements Serializable {

	private String temperatureIntegerNumber;
	private String temperatureSmallNumber;
	private String temperature;
	private String checkItem1;
	private String checkItem2;
	private String checkItem3;
	private String checkItem4;
	private String checkItem5;
	private String checkItem6;
	private String checkItem7;
	private String checkItem8;
	private String checkItem9;
	private String checkItem10;
	private String checkItem11;
	private String checkItem12;
	private String checkItem13;
	private String checkItem14;
	private String checkItem15;
	private String checkItem16;
	private String checkItem17;
	private String checkItem18;


	public String getTemperatureIntegerNumber() {
		return temperatureIntegerNumber;
	}

	public void setTemperatureIntegerNumber(String temperatureIntegerNumber) {
		this.temperatureIntegerNumber = temperatureIntegerNumber;
	}

	public String getTemperatureSmallNumber() {
		return temperatureSmallNumber;
	}

	public void setTemperatureSmallNumber(String temperatureSmallNumber) {
		this.temperatureSmallNumber = temperatureSmallNumber;
	}

	public String getTemperature() {
		return temperature;
	}

	public void setTemperature(String temperature) {
		this.temperature = temperature;
	}

	public String getCheckItem1() {
		return checkItem1;
	}

	public void setCheckItem1(String checkItem1) {
		this.checkItem1 = checkItem1;
	}

	public String getCheckItem2() {
		return checkItem2;
	}

	public void setCheckItem2(String checkItem2) {
		this.checkItem2 = checkItem2;
	}

	public String getCheckItem3() {
		return checkItem3;
	}

	public void setCheckItem3(String checkItem3) {
		this.checkItem3 = checkItem3;
	}

	public String getCheckItem4() {
		return checkItem4;
	}

	public void setCheckItem4(String checkItem4) {
		this.checkItem4 = checkItem4;
	}

	public String getCheckItem5() {
		return checkItem5;
	}

	public void setCheckItem5(String checkItem5) {
		this.checkItem5 = checkItem5;
	}

	public String getCheckItem6() {
		return checkItem6;
	}

	public void setCheckItem6(String checkItem6) {
		this.checkItem6 = checkItem6;
	}

	public String getCheckItem7() {
		return checkItem7;
	}

	public void setCheckItem7(String checkItem7) {
		this.checkItem7 = checkItem7;
	}

	public String getCheckItem8() {
		return checkItem8;
	}

	public void setCheckItem8(String checkItem8) {
		this.checkItem8 = checkItem8;
	}

	public String getCheckItem9() {
		return checkItem9;
	}

	public void setCheckItem9(String checkItem9) {
		this.checkItem9 = checkItem9;
	}

	public String getCheckItem10() {
		return checkItem10;
	}

	public void setCheckItem10(String checkItem10) {
		this.checkItem10 = checkItem10;
	}

	public String getCheckItem11() {
		return checkItem11;
	}

	public void setCheckItem11(String checkItem11) {
		this.checkItem11 = checkItem11;
	}

	public String getCheckItem12() {
		return checkItem12;
	}

	public void setCheckItem12(String checkItem12) {
		this.checkItem12 = checkItem12;
	}

	public String getCheckItem13() {
		return checkItem13;
	}

	public void setCheckItem13(String checkItem13) {
		this.checkItem13 = checkItem13;
	}

	public String getCheckItem14() {
		return checkItem14;
	}

	public void setCheckItem14(String checkItem14) {
		this.checkItem14 = checkItem14;
	}

	public String getCheckItem15() {
		return checkItem15;
	}

	public void setCheckItem15(String checkItem15) {
		this.checkItem15 = checkItem15;
	}

	public String getCheckItem16() {
		return checkItem16;
	}

	public void setCheckItem16(String checkItem16) {
		this.checkItem16 = checkItem16;
	}

	public String getCheckItem17() {
		return checkItem17;
	}

	public void setCheckItem17(String checkItem17) {
		this.checkItem17 = checkItem17;
	}

	public String getCheckItem18() {
		return checkItem18;
	}

	public void setCheckItem18(String checkItem18) {
		this.checkItem18 = checkItem18;
	}

}
