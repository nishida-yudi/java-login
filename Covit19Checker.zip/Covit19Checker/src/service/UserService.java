package service;

import java.util.List;

import dao.UsersDao;
import entity.UserEntity;
import util.Util;

/**
 * ユーザサービス
 */
public class UserService {


	public List<UserEntity> searchUser(UserEntity condition) {
		UsersDao usersDao = new UsersDao();
		UserEntity userEntity = new UserEntity();
		userEntity.setLoginId(condition.getLoginId());
		String passwordMd5 = Util.digest(condition.getLoginPassword());
		userEntity.setLoginPassword(passwordMd5);
		return usersDao.findLoginId(userEntity);
	}
}


