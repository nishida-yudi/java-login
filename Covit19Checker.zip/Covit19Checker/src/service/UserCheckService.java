package service;

import java.util.ArrayList;
import java.util.List;

import dao.UsersDao;
import dto.UserRegistDto;



public  class UserCheckService {
	public  List<String> checkInput(UserRegistDto userRegistDto){

		boolean i = UsersDao.usersRegist(userRegistDto);
		List<String> list = new ArrayList<String>();
		if(i==true) {
			list.add("このIDは既に使用されています。別のIDを入力して下さい。");
		}

		return list;
	}
}

