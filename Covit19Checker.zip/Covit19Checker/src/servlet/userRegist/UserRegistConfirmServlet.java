package servlet.userRegist;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.UserRegistEntity;
import service.TestService;

/**
 * Servlet implementation class UserRegistCompleteServlet
 */
@WebServlet("/UserRegistConfirmServlet")
public class UserRegistConfirmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String loginId = request.getParameter("loginId");
		String loginPassword = request.getParameter("loginPassword");
		String usersName = request.getParameter("usersName");
		String normalTemperature = request.getParameter("normalTemperature");
		String className = request.getParameter("className");
		String dropoutFlag = request.getParameter("dropoutFlag");



		UserRegistEntity userRegistEntity = new UserRegistEntity();
		userRegistEntity.setLoginId(loginId);
		userRegistEntity.setLoginPassword(loginPassword);
		userRegistEntity.setUsersName(usersName);
		userRegistEntity.setNormalTemperature(normalTemperature);
		userRegistEntity.setClassName(className);
		userRegistEntity.setDropoutFlag(dropoutFlag);






		TestService testService = new TestService();
		testService.search(userRegistEntity);







		RequestDispatcher dispatcher = request.getRequestDispatcher("public/userRegistComplete.jsp");
		dispatcher.forward(request, response);

		//response.sendRedirect("/userRegistComplete.jsp");
	}

}
