package service;

import java.util.ArrayList;
import java.util.List;

import entity.UserEntity;

public class UserListService {

	public List<UserEntity> overwriteUserList(List<UserEntity> sessionUsersList , List<UserEntity> requestUsersList ) {

		List<UserEntity> sessionList = sessionUsersList;
		List<UserEntity> requestList = requestUsersList;
		List<UserEntity> overWriteResultList = new ArrayList<UserEntity>();


		for (UserEntity sessionUserEntity : sessionList) {
			for (UserEntity requestUserEntity : requestList) {

//				//【確認用】
//				System.out.println("----------------------------------------------------");
//				System.out.println("[UserListService]requestUserEntity.getUsersName() =>" + requestUserEntity.getUsersName());
//				System.out.println("[UserListService]sessionUserEntity.getUsersName() =>" + sessionUserEntity.getUsersName());
//				System.out.println("----------------------------------------------------");

				if(requestUserEntity.getUsersName().equals(sessionUserEntity.getUsersName()) ) {

					UserEntity resultUserEntity = new UserEntity();
					//セッションスコープ情報から設定
					resultUserEntity.setClassName(sessionUserEntity.getClassName());
					resultUserEntity.setId(sessionUserEntity.getId());
					resultUserEntity.setLoginId(sessionUserEntity.getLoginId());
					resultUserEntity.setNormalTemperature(sessionUserEntity.getNormalTemperature());
					resultUserEntity.setUsersName(sessionUserEntity.getUsersName());
					//リスエストスコープ情報から設定
					resultUserEntity.setDropoutFlag(requestUserEntity.getDropoutFlag());

					overWriteResultList.add(resultUserEntity);
				}

			}
		}

		return overWriteResultList;
	}
}
