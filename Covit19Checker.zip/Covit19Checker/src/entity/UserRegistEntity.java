package entity;

public class UserRegistEntity {



	private String id;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getLoginPassword() {
		return loginPassword;
	}
	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}
	public String getUsersName() {
		return usersName;
	}
	public void setUsersName(String usersName) {
		this.usersName = usersName;
	}
	public String getNormalTemperature() {
		return normalTemperature;
	}
	public void setNormalTemperature(String normalTemperature) {
		this.normalTemperature = normalTemperature;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getDropoutFlag() {
		return dropoutFlag;
	}
	public void setDropoutFlag(String dropoutFlag) {
		this.dropoutFlag = dropoutFlag;
	}
	private String loginId;
	private String loginPassword;
	private String usersName;
	private String normalTemperature;
	private String className;
	private String dropoutFlag;

}
