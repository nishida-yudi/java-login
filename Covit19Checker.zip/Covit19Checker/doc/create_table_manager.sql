create table manager(
	id				  serial,
	login_id        char(10),
	login_password  char(32),
  	primary key(id)
);