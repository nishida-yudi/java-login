package servlet.login;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import constant.Constant;
import entity.UserEntity;
import service.UserService;

/**
 * Servlet implementation class UserLoginServlet
 */
@WebServlet("/UserLoginServlet")
public class UserLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		String loginId = request.getParameter("loginId");
		String loginPassword = request.getParameter("loginPassword");

		UserService userService = new UserService();

		UserEntity userEntity = new UserEntity();
		userEntity.setLoginId(loginId);
		userEntity.setLoginPassword(loginPassword);


		List<String> errorMessage = new ArrayList<String>();
				if(loginId.length()==0) {
				 errorMessage.add("ログインIDを入力してください");
				}
				 if(loginPassword.length()==0) {
					 errorMessage.add("パスワードを入力してください");
				 }
				 if(loginId.length()<5 || loginId.length()>10) {
					 errorMessage.add( "ユーザIDは5～10桁の半角英数字で入力してくだい。");
				 }
				 if(loginPassword.length()<4 || loginPassword.length()>8) {
					 errorMessage.add("パスワードは4〜8桁の半角英数字で入力してくだい。");
				}

				 if( errorMessage.size()>=1) {
					request.setAttribute("errorMessage",errorMessage );
					RequestDispatcher dispatcher = request.getRequestDispatcher("/public/userLogin.jsp");
					dispatcher.forward(request, response);
					 return;
				}


				 List<UserEntity> userList = userService.searchUser(userEntity);
				// if(userList.size() == 0) {
				 if(userList.isEmpty()) {
					 //ログイン画面へ遷移する
					 request.setAttribute("errorMessage", "ログインIDまたはパスワードが違います");
					 RequestDispatcher dispatcher = request.getRequestDispatcher("/public/userLogin.jsp");
					 dispatcher.forward(request, response);
					 return;
				 }

					HttpSession session = request.getSession();
					session.setAttribute(Constant.SESSION_KEY_LOGIN_INFO, userList.get(0));

		RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/userMenu.jsp");
		dispatcher.forward(request, response);
	}

 }
